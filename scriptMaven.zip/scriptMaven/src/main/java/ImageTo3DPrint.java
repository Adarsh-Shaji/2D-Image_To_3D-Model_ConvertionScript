import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

public class ImageTo3DPrint {

    public static void main(String[] args) {
        String inputImageJpg = "teddyjpg.jpg";
        String inputImage = "inputImage.bmp";
        String outputImageSvg = "output_image.svg";
        String outputBaseSvg = "output_base.svg";
        String openscadScript = "extrude.scad";
        String outputStl = "output_model.stl";

        String printerSettings = "Ender-3 Max Neo.json";
        String outputGcode = "output_model.gcode";

        String inputBase = "inputImage_without_bg.png";
        String outerSvg = "outer_svg.bmp";


        try {
            convertImageToBmpWithResize(inputImageJpg,inputImage);
            removeBackground("nnFFpZn5YHbXDPQrFK4cL9y7",inputImageJpg,inputBase);
            resizeImage(inputBase,inputBase);
            createDarkShadow(inputBase,outerSvg);
            convertToSvg(inputImage, outputImageSvg,0.6);
            invertImage(outerSvg,outerSvg);
            convertToSvg(outerSvg,outputBaseSvg,0.5);
            createOpenScadScript(outputBaseSvg,outputImageSvg, openscadScript);
            generateStl(openscadScript, outputStl);
            //sliceToGcode(outputStl, printerSettings, outputGcode);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void convertImageToBmpWithResize(String inputPath, String outputPath) throws IOException {
        // Determine the file type based on the file extension
        String fileExtension = getFileExtension(inputPath);
        if (!fileExtension.equalsIgnoreCase("jpg")) {
            throw new IllegalArgumentException("Unsupported file format: " + fileExtension);
        }

        // Read the input file
        File inputFile = new File(inputPath);
        BufferedImage originalImage = ImageIO.read(inputFile);
        if (originalImage == null) {
            throw new IOException("The file could not be read as an image or the format is not supported.");
        }

        // Resize the image to 225x225
        BufferedImage resizedImage = new BufferedImage(225, 225, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = resizedImage.createGraphics();

        // Draw the original image resized into the new BufferedImage
        g.drawImage(originalImage, 0, 0, 225, 225, null);
        g.dispose();

        // Write the image as BMP
        File outputFile = new File(outputPath);
        ImageIO.write(resizedImage, "BMP", outputFile);
    }

    private static String getFileExtension(String filePath) {
        int dotIndex = filePath.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < filePath.length() - 1) {
            return filePath.substring(dotIndex + 1);
        }
        return "";
    }

    // Step 1: Convert Bitmap to SVG using Potrace
    private static void convertToSvg(String inputImage, String outputSvg,double threshold) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("potrace", "-s","-k", String.valueOf(threshold), inputImage, "-o", outputSvg);
        Process process = pb.start();
        process.waitFor();
    }

    public static void resizeImage(String inputPath, String resizedPath) throws IOException, InterruptedException {
        String imagemagickPath = "C:\\Program Files\\ImageMagick-6.9.13-Q16-HDRI\\convert.exe";

        // Resize the image to 225x225 pixels
        ProcessBuilder pb = new ProcessBuilder(
                imagemagickPath,
                inputPath,
                "-resize", "225x225!",
                resizedPath
        );

        pb.redirectErrorStream(true); // Combine stdout and stderr
        Process process = pb.start();

        // Read output from the command to debug
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException("Image resizing failed with exit code " + exitCode);
        }
    }
    private static void createOpenScadScript(String baseSvg, String imageSvg, String openscadScript) throws IOException, Exception {
        int[] dimensions = getSvgDimensions(baseSvg);
        double width = dimensions[0];
        double height = dimensions[1];

        String scriptContent = "    linear_extrude(height = 20, center = true) {\n" +
                "        import(\"" + baseSvg + "\", center = true);\n" +
                "    }\n" +
                "\n" +
                "\n" +
                "translate([0, 0, 10]) {\n" +
                "    scale([0.98, 0.99, 1]) {\n" +
                "        linear_extrude(height = 3, center = true) {\n" +
                "            import(\"" + imageSvg + "\", center = true);\n" +
                "        }\n" +
                "    }\n" +
                "}\n";


        try (BufferedWriter writer = new BufferedWriter(new FileWriter(openscadScript))) {
            writer.write(scriptContent);
        }
    }



    private static void generateStl(String openscadScript, String outputStl) throws IOException, InterruptedException {
        String openscadPath = "C:\\Program Files\\OpenSCAD\\openscad.exe";

        ProcessBuilder pb = new ProcessBuilder(openscadPath, "-o", outputStl, openscadScript);
        Process process = pb.start();
        process.waitFor();
    }

//    private static void sliceToGcode(String outputStl, String printerSettings, String outputGcode) throws IOException, InterruptedException {
//        String curaenginePath = "C:\\Program Files\\UltiMaker Cura 5.7.1\\CuraEngine.exe";
//
//        // Verify that the files exist
//        File stlFile = new File(outputStl);
//        File settingsFile = new File(printerSettings);
//        File curaEngineFile = new File(curaenginePath);
//
//        if (!curaEngineFile.exists()) {
//            System.err.println("Error: CuraEngine executable not found at " + curaenginePath);
//            return;
//        }
//        if (!stlFile.exists()) {
//            System.err.println("Error: STL file not found at " + outputStl);
//            return;
//        }
//        if (!settingsFile.exists()) {
//            System.err.println("Error: Printer settings file not found at " + printerSettings);
//            return;
//        }
//
//        ProcessBuilder pb = new ProcessBuilder(
//                curaenginePath,
//                "slice",
//                "-j", printerSettings,
//                "-l", outputStl,
//                "-o", outputGcode
//        );
//
//        pb.redirectErrorStream(true);  // Merge standard error with standard output
//        Process process = pb.start();
//
//        // Capture output from the process
//        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
//            String line;
//            while ((line = reader.readLine()) != null) {
//                System.out.println(line);
//            }
//        }
//
//        int exitCode = process.waitFor();
//        if (exitCode == 0) {
//            System.out.println("G-code generation completed successfully.");
//        } else {
//            System.err.println("Error: G-code generation failed with exit code " + exitCode);
//        }
//    }


    private static void sliceToGcode(String outputStl, String printerSettings, String outputGcode) throws IOException, InterruptedException {
        String crealityPrintPath = "C:\\Program Files\\Creality Print\\Creative3D.exe";

        // Verify that the files exist
        File stlFile = new File(outputStl);
        File settingsFile = new File(printerSettings);
        File crealityPrintExecutable = new File(crealityPrintPath);

        if (!crealityPrintExecutable.exists()) {
            System.err.println("Error: Creality Print executable not found at " + crealityPrintPath);
            return;
        }
        if (!stlFile.exists()) {
            System.err.println("Error: STL file not found at " + outputStl);
            return;
        }
        if (!settingsFile.exists()) {
            System.err.println("Error: Printer settings file not found at " + printerSettings);
            return;
        }

        ProcessBuilder pb = new ProcessBuilder(
                crealityPrintPath,
                "slice",
                "-j", printerSettings,
                "-l", outputStl,
                "-o", outputGcode
        );

        pb.redirectErrorStream(true); // Merge standard error with standard output
        Process process = pb.start();

        // Capture output from the process
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }

        int exitCode = process.waitFor();
        if (exitCode == 0) {
            System.out.println("G-code generation completed successfully.");
        } else {
            System.err.println("Error: G-code generation failed with exit code " + exitCode);
        }
    }


    public static void createDarkShadow(String inputPath, String outputPath) throws IOException, InterruptedException {
        String imagemagickPath = "C:\\Program Files\\ImageMagick-6.9.13-Q16-HDRI\\convert.exe";

        // Adjust the command to handle special characters correctly
        ProcessBuilder pb = new ProcessBuilder(
                imagemagickPath,
                inputPath,
                "-colorspace", "Gray",
                "-normalize",
                "-threshold", "100%",
                "(",
                "+clone",
                "-morphology", "edge", "diamond:1",
                "-negate",
                ")",
                "-compose", "over",
                "-composite",
                outputPath
        );

        pb.redirectErrorStream(true); // Combine stdout and stderr
        Process process = pb.start();

        // Read output from the command to debug
        java.io.InputStream is = process.getInputStream();
        java.io.BufferedReader reader = new java.io.BufferedReader(new InputStreamReader(is));
        String line = null;
        while ((line = reader.readLine()) != null) {
            System.out.println(line);
        }

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException("Image processing failed with exit code " + exitCode);
        }
    }


    public static int[] getSvgDimensions(String svgPath) throws Exception {
        File inputFile = new File(svgPath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();

        Element svgRoot = doc.getDocumentElement();
        double svgWidth = parseDimension(svgRoot.getAttribute("width"));
        double svgHeight = parseDimension(svgRoot.getAttribute("height"));

        NodeList imageNodes = svgRoot.getElementsByTagName("image");
        if (imageNodes.getLength() > 0) {
            Element imageElement = (Element) imageNodes.item(0);
            double imageWidth = parseDimension(imageElement.getAttribute("width"));
            double imageHeight = parseDimension(imageElement.getAttribute("height"));
            return new int[]{(int) Math.round(imageWidth), (int) Math.round(imageHeight)};
        }

        return new int[]{(int) Math.round(svgWidth), (int) Math.round(svgHeight)};
    }

    private static double parseDimension(String dimension) {
        if (dimension == null || dimension.isEmpty()) {
            return 0;
        }
        dimension = dimension.trim();

        double multiplier = 1.0;
        if (dimension.endsWith("px")) {
            dimension = dimension.substring(0, dimension.length() - 2);
            multiplier = 0.264583;  // Convert pixels to millimeters
        } else if (dimension.endsWith("pt")) {
            dimension = dimension.substring(0, dimension.length() - 2);
            multiplier = 0.352778;  // Convert points to millimeters (1pt = 0.352778mm)
        } else if (dimension.endsWith("cm")) {
            dimension = dimension.substring(0, dimension.length() - 2);
            multiplier = 10.0;  // Convert centimeters to millimeters
        } else if (dimension.endsWith("mm")) {
            dimension = dimension.substring(0, dimension.length() - 2);
            multiplier = 1.0;  // Millimeters remain the same
        } else if (dimension.endsWith("in")) {
            dimension = dimension.substring(0, dimension.length() - 2);
            multiplier = 25.4;  // Convert inches to millimeters
        }

        return Double.parseDouble(dimension) * multiplier;
    }


    public static void removeBackground(String apiKey, String inputImagePath, String outputImagePath) throws IOException {
        File inputFile = new File(inputImagePath);
        HttpResponse<byte[]> response = Unirest.post("https://api.remove.bg/v1.0/removebg")
                .header("X-Api-Key", apiKey)
                .field("image_file", inputFile)
                .field("size", "auto")
                .asBytes();

        if (response.isSuccess()) {
            System.out.println("Background removed successfully!");
            saveImage(response.getBody(), outputImagePath);
        } else {
            System.out.println("Failed to remove background: " + response.getStatusText());
            System.out.println("HTTP Status Code: " + response.getStatus());
            System.out.println("Error Message: " + new String(response.getBody()));
        }

    }

    private static void saveImage(byte[] imageBytes, String outputImagePath) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(outputImagePath)) {
            fos.write(imageBytes);
        } catch (IOException e) {
            throw new IOException("Failed to save the output image", e);
        }
    }


    public static boolean invertImage(String inputImagePath, String outputImagePath) {
        // Specify the full path to the ImageMagick convert command
        String imagemagickPath = "C:\\Program Files\\ImageMagick-6.9.13-Q16-HDRI\\convert.exe";

        // Initialize the ProcessBuilder with the full path to convert.exe
        ProcessBuilder processBuilder = new ProcessBuilder(imagemagickPath, inputImagePath, "-negate", outputImagePath);

        processBuilder.redirectErrorStream(true); // Combine stdout and stderr for easier debugging.

        try {
            // Start the process
            Process process = processBuilder.start();

            // To help debug, let's read the output from the command:
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();

            // Check the exit code
            return exitCode == 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}
